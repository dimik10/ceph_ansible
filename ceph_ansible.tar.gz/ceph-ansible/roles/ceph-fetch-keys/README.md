# Ansible role: ceph-fetch

Documentation is available at http://docs.ceph.com/ceph-ansible/.

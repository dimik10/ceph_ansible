# Ansible role: ceph-facts

Documentation is available at http://docs.ceph.com/ceph-ansible/.

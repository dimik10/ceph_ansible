Ceph Ansible
==============

    The project is still maintained for the time being but it is encouraged to migrate to `cephadm <https://docs.ceph.com/en/latest/cephadm/>`_.

Ansible playbooks for Ceph, the distributed object, block, and file storage platform.

Please refer to our hosted documentation here: https://docs.ceph.com/projects/ceph-ansible/en/latest/
You can view documentation for our ``stable-*`` branches by substituting ``main`` in the link
above for the name of the branch. For example: https://docs.ceph.com/projects/ceph-ansible/en/stable-8.0/
